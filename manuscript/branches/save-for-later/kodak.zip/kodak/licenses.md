
# canon-rc-701.jpg

- https://commons.wikimedia.org/wiki/File:Canon_RC-701_CP%2B_2011.jpg
- by Morio
- [Creative Commons Attribution-Share Alike 3.0 Unported](https://creativecommons.org/licenses/by-sa/3.0/deed.en)

# digital.jpg

- https://www.flickr.com/photos/socsci/31380508405/in/photolist-PNZiSn
- by Mr. Gray
- public domain

# folding-pocket-kodak.jpg

- https://en.wikipedia.org/wiki/File:Kodak_pocket_camera_advertisement_1900.JPG
- by Eastman Kodak Company
- public domain

# instamatic.jpg

- https://www.flickr.com/photos/28438417@N08/34799266963/in/photostream/
- by Ashley Basil
- [Creative Commons Attribution 2.0 Generic (CC BY 2.0)](https://creativecommons.org/licenses/by/2.0/)

# kodachrome.jpg

- https://commons.wikimedia.org/wiki/File:Kodachrome_K135_20_Color_Reversal_Film_Expired_in_1961.jpg
- by Thistle33
- [Creative Commons Attribution-Share Alike 4.0 International](https://commons.wikimedia.org/wiki/File:Kodachrome_K135_20_Color_Reversal_Film_Expired_in_1961.jpg)

# kodak.jpg

- https://en.wikipedia.org/wiki/File:One_Kodak_Camera.jpg
- by Kodakcollector
- [Creative Commons Attribution-Share Alike 3.0 Unported](https://creativecommons.org/licenses/by-sa/3.0/deed.en)

# kodamatic.jpg

- https://commons.wikimedia.org/wiki/File:Kodak_Kodamatic_940_(2167856100).jpg
- by Terri Monahan
- [Creative Commons Attribution-Share Alike 2.0 Generic](https://creativecommons.org/licenses/by-sa/2.0/deed.en)

# logitech-fotoman.jpg

- https://commons.wikimedia.org/wiki/File:Logitech_FotoMan-P4191196-black.jpg
- by Rama
- [Creative Commons Attribution-ShareAlike 3.0 France](https://creativecommons.org/licenses/by-sa/2.0/fr/deed.en)

# quicktake.jpg

- https://commons.wikimedia.org/wiki/File:QuickTake_hinten.jpg
- by Gmhofmann
- public domain

# slogan.jpg

- https://commons.wikimedia.org/wiki/File:You_press_the_button,_we_do_the_rest_(Kodak).jpg
- unknown author, advertising
- public domain

# sony-mavica.jpg

- https://commons.wikimedia.org/wiki/File:Sony_Mavica_1981_prototype_CP%2B_2011.jpg
- by Morio
- - [Creative Commons Attribution-Share Alike 3.0 Unported](https://creativecommons.org/licenses/by-sa/3.0/deed.en)

# starmatic.jpg

- https://www.flickr.com/photos/mpclemens/2436099905
- by mpclemens
- [Creative Commons Attribution 2.0 Generic (CC BY 2.0)](https://creativecommons.org/licenses/by/2.0/)
